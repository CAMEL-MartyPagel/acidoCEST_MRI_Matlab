/****************************************************************
 *
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/FISP/relProtos.h,v $
 *
 * Copyright (c) 1999
 * BRUKER MEDICAL GMBH
 * D-76275 Ettlingen, Germany
 *
 * All Rights Reserved
 *
 *
 * $Id: relProtos.h,v 1.1 2002/06/20 12:43:57 fhen Exp $
 *
 ****************************************************************/

#if ! defined(__METHRELS_H__)
#       define __METHRELS_H__
#include "relProtos_p.h"
#endif

/****************************************************************/
/*      E N D   O F   F I L E                                   */
/****************************************************************/

